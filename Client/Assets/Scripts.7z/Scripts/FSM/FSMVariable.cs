﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlGame.FSM
{
    public static class FSMVariable
    {
        public const float IgnoreDistance = 0.8f;

        public const float MoveDistance = 0.5f;

        //public const float Deviation = 0.5f;
    }
}
