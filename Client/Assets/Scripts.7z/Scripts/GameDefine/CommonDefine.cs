﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDefine
{
    public static class CommonDefine
    {
        public const int MAX_LEVEL = 15;
        public const float CameraGrayTime = 1.5f;
    }
}
