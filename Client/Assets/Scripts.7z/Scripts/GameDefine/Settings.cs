﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDefine
{
    public static class Settings
    {
        public static float AudioVolume = 1.0f;

        public static int MaxEffectAudioSource = 10;
        public static int LongVoiceAudioSourceQueue = 10;
    }
}
