﻿using UnityEngine;
using System.Collections;

namespace GameDefine
{
    public static class MsgContentDefine
    {
        public static string CONNECTING_SERVER = "正在连接服务器...";
        public static string CONNECTING_WAITING = "请稍等...";
        public static string RECONNECT_CONTENT = "重新连接";
        public static string DISCONNECT_CONTENT = "您与服务器断开连接...";
        public static string CONNECT_FAILD = "连接服务器失败...";
        public static string RECONNECTTOBAttle = "您有一场战斗正在进行，请尝试...";

        //public static string RECONNECT
    }
}


