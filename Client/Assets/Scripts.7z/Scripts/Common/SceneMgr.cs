using UnityEngine;
using System;
using System.Collections;
using System.Threading;
using JT.FWW.Tools;
using JT.FWW.GameData;

public interface ISceneMgr
{
    //Int32 OnEvent_AddSelfGameEntity(CGameEntityBaseInfo pcBaseInfo);
    //Int32 OnEvent_RemoveSelfGameEntity(CGameEntityBaseInfo pcBaseInfo);
    //Int32 OnEvent_AddWorldGameEntity(CGameEntityBaseInfo pcBaseInfo);
    //Int32 OnEvent_RemoveWorldGameEntity(CGameEntityBaseInfo pcBaseInfo);
    //Int32 OnEvent_DestoryGameEntity(CGameEntityBaseInfo pcBaseInfo);
}
