﻿using UnityEngine;
using System.Collections;
using BlGame.Effect;

public class SL_DestroyByTime : MonoBehaviour
{
    //public float destroyTime = 5;

    //void OnEnable()
    //{
    //    Invoke("EffectDestroy", destroyTime);
    //}

    //public void EffectDestroy()
    //{
    //    EffectObject effObj = transform.GetComponent<EffectObject>();
    //    if (effObj)
    //        EffectManager.Instance.DestroyEffect(effObj.effectId);
    //    else
    //        Destroy(gameObject);
    //}
}