﻿using UnityEngine;
using System.Collections;

public class UITalks : MonoBehaviour {
    public static UITalks Instance
    {
        private set;
        get;
    }
	
}
