﻿using UnityEngine;
using System.Collections;

public class Tower : Entity {

    public override void Start()
    {
        //base.Start();
    }

    //public void 

    //public override 
}
