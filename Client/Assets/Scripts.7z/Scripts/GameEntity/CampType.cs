using UnityEngine;
using System.Collections;

namespace BlGame.GameEntity
{
	public enum EntityCampType{
		CampTypeNull = -2,
		CampTypeBad,   //ȫ�ж�
		CampTypeKind,  //ȫ��ƽ
		CampTypeA,
		CampTypeB,
		CampTypeC,
		CampTypeD,
		CampTypeE,
		CampTypeF,
	}
	
}
