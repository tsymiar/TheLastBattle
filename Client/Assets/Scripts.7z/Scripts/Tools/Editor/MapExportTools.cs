﻿using UnityEngine;
using System.Collections;

public class NewBehaviourScript : MonoBehaviour {

//	struct SMapHeader
//	{
//		INT32 n32GoodsNum;
//		INT32 n32Width;
//		INT32 n32Height;
//	};
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

//		File pcFile = createfile ();
//
//		SMapHeader sTempHeader;
//		sTempHeader.n32GoodsNum = 30;
//		sTempHeader.n32Width = 200;
//		sTempHeader.n32Height = 200;
//
//		pcFile.Write (sTempHeader);

//		for(INT32 i = 0; i < sTempHeader.30; i++)
//		{
//			pcFile.Write(i + 100);
//		}
//
//		for(INT32 i = 0; i < sTempHeader.n32Width * sTempHeader.n32Height; i++)
//		{
//			pcFile.Write(0);
//		}
//
//		for(INT32 i = 0; i < sTempHeader.n32Width * sTempHeader.n32Height; i++)
//		{
//			pcFile.Write(36);
//		}




	}
}
