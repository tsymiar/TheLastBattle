﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlGame.Model
{
    public class AdvancedGuideModel : Singleton<AdvancedGuideModel>
    {

    }
}
