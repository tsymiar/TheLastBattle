﻿using UnityEngine;
using System.Collections;
using System;

namespace BlGame.GameData
{
    public class PlayerBattleData
    {
        //struct PersonDate
        //{
            //public int camp;
            public UInt32 HeadId;
            public UInt32 Level;
            public UInt32 Hp;
            public UInt32 Mp;
        //}
        //public PersonDate Data;
        public PlayerBattleData()
        {
            //Data = new PersonDate();
        }
    }
}