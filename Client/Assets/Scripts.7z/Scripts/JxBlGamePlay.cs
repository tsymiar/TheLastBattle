﻿using UnityEngine;
using System.Collections;

public class JxBlGamePlay : MonoBehaviour {

	// Use this for initialization
	void Start () {
//		JxBlGame.Instance.
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
